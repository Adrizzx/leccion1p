class ConsumoModel {
  final int minutos;
  final double gigas;
  final int minutosExceso;
  final double gigasExceso;
  final double costoMinutos;
  final double costoGigas;
  final double totalAdicional;

  ConsumoModel({
    required this.minutos,
    required this.gigas,
    required this.minutosExceso,
    required this.gigasExceso,
    required this.costoMinutos,
    required this.costoGigas,
    required this.totalAdicional,
  });
}
