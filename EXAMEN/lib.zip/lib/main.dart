import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'view_model/consumo_viewmodel.dart';
import 'view/pantallas/inicio_pantalla.dart';
import 'view/pantallas/principal_pantalla.dart';
import 'view/pantallas/resultado_pantalla.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => ConsumoViewModel(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Plan telefonico',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        scaffoldBackgroundColor: Colors.grey.shade100,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const InicioPantalla(),
        '/principal': (context) => const PrincipalPantalla(),
        '/resultado': (context) => const ResultadoPantalla(),
      },
    );
  }
}
