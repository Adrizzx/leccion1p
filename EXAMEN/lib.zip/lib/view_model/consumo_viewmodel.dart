import 'package:flutter/material.dart';
import '../model/consumo_model.dart';

class ConsumoViewModel extends ChangeNotifier {
  //datos del plan
  final int minutosPlan = 300;
  final double gigasPlan = 10;
  final double precioMinuto = 0.05;
  final double precioGiga = 2;

  String mensaje = '';

  //valida y calcula, si hay error devuelve null
  ConsumoModel? calcular(String textoMinutos, String textoGigas) {
    int? minutos = int.tryParse(textoMinutos);
    double? gigas = double.tryParse(textoGigas.replaceAll(',', '.'));

    if (textoMinutos.isEmpty || textoGigas.isEmpty) {
      mensaje = 'Ingrese los minutos y los GB consumidos';
      notifyListeners();
      return null;
    }
    if (minutos == null) {
      mensaje = 'Los minutos deben ser un numero entero';
      notifyListeners();
      return null;
    }
    if (gigas == null) {
      mensaje = 'Los GB deben ser un numero valido';
      notifyListeners();
      return null;
    }
    if (minutos < 0 || gigas < 0) {
      mensaje = 'No se permiten valores negativos';
      notifyListeners();
      return null;
    }

    //excesos
    int minutosExceso = 0;
    if (minutos > minutosPlan) {
      minutosExceso = minutos - minutosPlan;
    }
    double gigasExceso = 0;
    if (gigas > gigasPlan) {
      gigasExceso = gigas - gigasPlan;
    }

    //costos
    double costoMinutos = minutosExceso * precioMinuto;
    double costoGigas = gigasExceso * precioGiga;
    double totalAdicional = costoMinutos + costoGigas;

    mensaje = '';
    notifyListeners();

    return ConsumoModel(
      minutos: minutos,
      gigas: gigas,
      minutosExceso: minutosExceso,
      gigasExceso: gigasExceso,
      costoMinutos: costoMinutos,
      costoGigas: costoGigas,
      totalAdicional: totalAdicional,
    );
  }

  void limpiar() {
    mensaje = '';
    notifyListeners();
  }
}
