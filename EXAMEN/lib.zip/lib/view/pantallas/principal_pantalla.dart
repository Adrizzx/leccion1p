import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../view_model/consumo_viewmodel.dart';
import '../widgets/campo_numero.dart';

class PrincipalPantalla extends StatefulWidget {
  const PrincipalPantalla({super.key});

  @override
  State<PrincipalPantalla> createState() => _PrincipalPantallaState();
}

class _PrincipalPantallaState extends State<PrincipalPantalla> {
  //mapeo
  final minutosController = TextEditingController();
  final gigasController = TextEditingController();

  void calcular() {
    //leer el viewmodel sin escuchar cambios
    final vm = context.read<ConsumoViewModel>();
    final resultado = vm.calcular(minutosController.text.trim(), gigasController.text.trim());

    //si esta bien, pasa a resultados con arguments
    if (resultado != null) {
      Navigator.pushNamed(context, '/resultado', arguments: resultado);
    }
  }

  void limpiar() {
    minutosController.clear();
    gigasController.clear();
    context.read<ConsumoViewModel>().limpiar();
  }

  @override
  Widget build(BuildContext context) {
    //escucha los cambios del viewmodel
    final vm = context.watch<ConsumoViewModel>();

    return Scaffold(
      appBar: AppBar(
        title: Text('Consumo del mes', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Ingrese su consumo',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.indigo.shade800),
            ),
            SizedBox(height: 5),
            Text(
              'Plan: ${vm.minutosPlan} minutos y ${vm.gigasPlan.toStringAsFixed(0)} GB',
              style: TextStyle(color: Colors.grey.shade700),
            ),
            SizedBox(height: 20),
            CampoNumero(
              etiqueta: 'Minutos consumidos',
              ayuda: 'Ejemplo: 350',
              icono: Icons.call,
              controller: minutosController,
            ),
            SizedBox(height: 15),
            CampoNumero(
              etiqueta: 'GB consumidos',
              ayuda: 'Ejemplo: 12.5',
              icono: Icons.wifi,
              controller: gigasController,
            ),
            SizedBox(height: 15),
            if (vm.mensaje != '')
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red.shade50,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    Icon(Icons.error_outline, color: Colors.red),
                    SizedBox(width: 10),
                    Expanded(child: Text(vm.mensaje, style: TextStyle(color: Colors.red))),
                  ],
                ),
              ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: calcular,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.indigo,
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: Text('Calcular', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
            SizedBox(height: 10),
            OutlinedButton(
              onPressed: limpiar,
              style: OutlinedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: Text('Limpiar', style: TextStyle(fontSize: 16)),
            ),
          ],
        ),
      ),
    );
  }
}
