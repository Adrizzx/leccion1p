import 'package:flutter/material.dart';
import '../../model/consumo_model.dart';
import '../widgets/fila_dato.dart';

class ResultadoPantalla extends StatelessWidget {
  const ResultadoPantalla({super.key});

  @override
  Widget build(BuildContext context) {
    //recibir los parametros
    final consumo = ModalRoute.of(context)!.settings.arguments as ConsumoModel;
    bool sinExceso = consumo.totalAdicional == 0;

    return Scaffold(
      appBar: AppBar(
        title: Text('Resultado', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              elevation: 3,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: Column(
                children: [
                  FilaDato(titulo: 'Minutos consumidos', valor: '${consumo.minutos}'),
                  FilaDato(titulo: 'Minutos en exceso', valor: '${consumo.minutosExceso}'),
                  FilaDato(titulo: 'Costo por minutos', valor: '\$${consumo.costoMinutos.toStringAsFixed(2)}'),
                  Divider(),
                  FilaDato(titulo: 'GB consumidos', valor: consumo.gigas.toStringAsFixed(2)),
                  FilaDato(titulo: 'GB en exceso', valor: consumo.gigasExceso.toStringAsFixed(2)),
                  FilaDato(titulo: 'Costo por GB', valor: '\$${consumo.costoGigas.toStringAsFixed(2)}'),
                ],
              ),
            ),
            SizedBox(height: 15),
            Card(
              color: sinExceso ? Colors.green.shade50 : Colors.orange.shade50,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  children: [
                    Icon(
                      sinExceso ? Icons.check_circle : Icons.warning_amber,
                      size: 50,
                      color: sinExceso ? Colors.green : Colors.orange,
                    ),
                    SizedBox(height: 10),
                    Text('Valor adicional a pagar', style: TextStyle(fontSize: 16)),
                    SizedBox(height: 5),
                    Text(
                      '\$${consumo.totalAdicional.toStringAsFixed(2)}',
                      style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 5),
                    Text(
                      sinExceso ? 'No se paso del plan' : 'Se excedio del plan',
                      style: TextStyle(color: Colors.grey.shade700),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.indigo,
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: Text('Regresar', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
            SizedBox(height: 10),
            OutlinedButton(
              onPressed: () => Navigator.popUntil(context, ModalRoute.withName('/')),
              style: OutlinedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: Text('Ir al inicio', style: TextStyle(fontSize: 16)),
            ),
          ],
        ),
      ),
    );
  }
}
