import 'package:flutter/material.dart';

class FilaDato extends StatelessWidget {
  final String titulo;
  final String valor;

  const FilaDato({super.key, required this.titulo, required this.valor});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(titulo, style: TextStyle(color: Colors.grey.shade700)),
      trailing: Text(
        valor,
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: Colors.indigo.shade700,
        ),
      ),
    );
  }
}
